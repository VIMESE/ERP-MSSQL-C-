﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ergasia
{
    public partial class NewOrder : Form
    {
        public NewOrder()
        {
            InitializeComponent();

            FillComboBox1();
        

            comboBox1.SelectedIndex = 0;


            FillComboBox2();
            comboBox2.SelectedIndex = 0;
            textBox1.Text = "1";


           
        }



        private void FillComboBox2()
        {
            string connectionString = ConnectionData.connectionString;
            string categoryName = comboBox1.Text;
       
            string query = "productname";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@category", categoryName);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    comboBox2.Items.Add(reader["name"].ToString());
                }

                reader.Close();
            }
        }
 
 

private void FillComboBox1()
        {
            string connectionString = ConnectionData.connectionString;
            string query = "SELECT Name FROM Production.ProductCategory";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Console.WriteLine((reader["Name"].ToString()));
                    comboBox1.Items.Add(reader["Name"].ToString());
                }

                reader.Close();
            }
        }
   




    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillComboBox2();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int value = Int32.Parse(textBox1.Text) + 1;
            textBox1.Text = value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int value = Int32.Parse(textBox1.Text) - 1;
            if(value > 0)
            {
                textBox1.Text = value.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var index = this.dataGridView1.Rows.Add();
            this.dataGridView1.Rows[index].Cells[1].Value = comboBox2.SelectedValue;
            this.dataGridView1.Rows[index].Cells[0].Value = textBox1.SelectedText;
        }
    }
}
