﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ergasia
{
    internal class ConnectionData
    {

         //public static string connectionString = "Data Source=PE3-11;Initial Catalog=AdventureWorks2019;Integrated Security=True;";

        public static string connectionString = "Data Source=DESKTOP-5EPSD2F;Initial Catalog=AdventureWorks2019;User Id=sa;Password=7567;";





    }
}
