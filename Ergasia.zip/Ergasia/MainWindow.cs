﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Ergasia
{
    public partial class MainWindow : Form
    {



        private Boolean isCustomerStuffShown = false;

        private Boolean isAddSalesPersonPanelShown = false;
        private Boolean isSearchSalesPersonPanelShown = false;



        private Boolean isSalesPersonStuffShown = false;


        private Boolean isAddPanelShown = false;
        private Boolean isSearchPanelShown = false;


        public MainWindow()
        {
            InitializeComponent();


            isSalesPersonStuffShown = false;
            isAddSalesPersonPanelShown = false;
            isSearchSalesPersonPanelShown = false;
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();



            customerPanel.Hide();
            isCustomerStuffShown = false;
            panel1.Hide();
            isAddPanelShown = false;

            panel2.Hide();

            comboBox1.SelectedIndex = 1;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            textBox9.ReadOnly = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Toggle the visibility of the customer panel
            isCustomerStuffShown = !isCustomerStuffShown;

            // Hide the sales person panel if it's currently shown
            if (isCustomerStuffShown)
            {
                // Show the customer panel
                customerPanel.Show();

                // Hide the sales person panel
                panel3.Hide();

                // Set the flag for sales person panel to false
                isSalesPersonStuffShown = false;
            }
            else
            {
                // Hide the customer panel
                customerPanel.Hide();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // Toggle the visibility of the sales person panel
            isSalesPersonStuffShown = !isSalesPersonStuffShown;

            // Hide the customer panel if it's currently shown
            if (isSalesPersonStuffShown)
            {
                // Show the sales person panel
                panel3.Show();

                // Hide the customer panel
                customerPanel.Hide();

                // Set the flag for customer panel to false
                isCustomerStuffShown = false;
            }
            else
            {
                // Hide the sales person panel
                panel3.Hide();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (!isAddPanelShown)
            {
                isAddPanelShown = true;
                panel1.Show();
                customerGrid();
                comboBox2.SelectedIndex = 0;
                comboBox4.SelectedIndex = 0;
                comboBox3.SelectedIndex = 0;

                // Hide the search panel if it's currently shown
                if (isSearchPanelShown)
                {
                    isSearchPanelShown = false;
                    panel2.Hide();
                }
            }
            else
            {
                isAddPanelShown = false;
                panel1.Hide();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (!isSearchPanelShown)
            {
                isSearchPanelShown = true;
                panel2.Show();
                LoadData();

                // Hide the add panel if it's currently shown
                if (isAddPanelShown)
                {
                    isAddPanelShown = false;
                    panel1.Hide();
                }
            }
            else
            {
                isSearchPanelShown = false;
                panel2.Hide();
            }
        }



        private void customerGrid()
        {


            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to retrieve data
            string query = "select businessentityid, name from sales.store;";

            // DataTable to store the retrieved data
            DataTable dataTable = new DataTable();

            // Establish connection and execute the query
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Load data into the DataTable
                    dataTable.Load(reader);

                    // Close the reader and the connection
                    reader.Close();
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView2.DataSource = dataTable;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


            dataGridView2.RowHeadersVisible = false;



        }


        private void LoadData()
        {
            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to retrieve data
            string query = "exec vc;";

            // DataTable to store the retrieved data
            DataTable dataTable = new DataTable();

            // Establish connection and execute the query
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Load data into the DataTable
                    dataTable.Load(reader);

                    // Close the reader and the connection
                    reader.Close();
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dataTable;


            dataGridView1.Columns[0].Width = 155;
            dataGridView1.Columns[1].Width = 105;
            dataGridView1.Columns[2].Width = 90;
            dataGridView1.Columns[3].Width = 110;
            dataGridView1.Columns[4].Width = 95;


            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


            dataGridView1.RowHeadersVisible = false;
        }

        private void LoadDataCustomerID()
        {
            String text = textBox10.Text;
            if (IsArithmetic(text))
            {

                // Connection string to your SQL Server
                string connectionString = ConnectionData.connectionString;

                // SQL query to retrieve data
                string query = "exec customersearch @customerid =" + text + ";";
                Console.WriteLine(query);
                // DataTable to store the retrieved data
                DataTable dataTable = new DataTable();

                // Establish connection and execute the query
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        // Load data into the DataTable
                        dataTable.Load(reader);

                        // Close the reader and the connection
                        reader.Close();
                    }
                }

                // Bind the DataTable to the DataGridView
                dataGridView1.DataSource = dataTable;

                // Set minimum width for each column header
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    column.MinimumWidth = 128; // Adjust the width as needed
                }
            }
            else
            {
                MessageBox.Show("Not Aritmetic Value", "Error");
            }
        }

        public static bool IsArithmetic(string text)
        {
            try
            {
                // Attempt to parse the string as an arithmetic expression
                // If parsing succeeds, return true
                double result = Convert.ToDouble(new System.Data.DataTable().Compute(text, null));
                return true;
            }
            catch (Exception)
            {
                // If parsing fails, return false
                return false;
            }
        }
        private void LoadDataStoreID()
        {
            String text = textBox10.Text;
            if (IsArithmetic(text))
            {
                // Connection string to your SQL Server
                string connectionString = ConnectionData.connectionString;

                // SQL query to retrieve data
                string query = "exec customersearch @StoreID =" + text + ";";
                Console.WriteLine(query);
                // DataTable to store the retrieved data
                DataTable dataTable = new DataTable();

                // Establish connection and execute the query
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        // Load data into the DataTable
                        dataTable.Load(reader);

                        // Close the reader and the connection
                        reader.Close();
                    }
                }

                // Bind the DataTable to the DataGridView
                dataGridView1.DataSource = dataTable;

                // Set minimum width for each column header
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    column.MinimumWidth = 128; // Adjust the width as needed
                }
            }
            else
            {
                MessageBox.Show("Not Aritmetic Value", "Error");
            }
        }


        private void LoadLastNameData()
        {
            String text = textBox10.Text;
            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to retrieve data
            string query = "exec customersearch @Lastname =" + text + ";";
            Console.WriteLine(query);
            // DataTable to store the retrieved data
            DataTable dataTable = new DataTable();

            // Establish connection and execute the query
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Load data into the DataTable
                    dataTable.Load(reader);

                    // Close the reader and the connection
                    reader.Close();
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dataTable;

            // Set minimum width for each column header
            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.MinimumWidth = 128; // Adjust the width as needed
            }
        }





        private void deleteCustomer(int id)
        {
            // Define your connection string
            string connectionString = ConnectionData.connectionString;

            // Define the BusinessEntityID you want to pass to the stored procedure
            int businessEntityID = id; // Example value, replace with actual value

            // Create a SqlConnection object
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Create a SqlCommand object for the stored procedure
                using (SqlCommand command = new SqlCommand("dcus", connection))
                {
                    // Set the command type as stored procedure
                    command.CommandType = CommandType.StoredProcedure;

                    // Add parameters to the command
                    command.Parameters.AddWithValue("@businessentityid", businessEntityID);

                    try
                    {
                        // Open the connection
                        connection.Open();

                        // Execute the command
                        command.ExecuteNonQuery();

                        Console.WriteLine("Stored procedure executed successfully.");
                    }
                    catch (Exception ex)
                    {
                        // Handle any exceptions
                        Console.WriteLine("Error: " + ex.Message);
                    }
                }
            }
        }





        private void LoadAdressData()
        {
            String text = textBox10.Text;



            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to retrieve data
            string query = "exec customersearch @address =" + text + ";";

            Console.WriteLine(query);
            // DataTable to store the retrieved data
            DataTable dataTable = new DataTable();

            // Establish connection and execute the query
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Load data into the DataTable
                    dataTable.Load(reader);

                    // Close the reader and the connection
                    reader.Close();
                }
            }


        }


        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {


            if (comboBox1.Text.Equals("Customer ID"))
            {
                LoadDataCustomerID();
            }
            else if (comboBox1.Text.Equals("Store ID"))
            {
                LoadDataStoreID();
            }
            else if (comboBox1.Text.Equals("Address"))
            {
                LoadAdressData();
            }
            else if (comboBox1.Text.Equals("LastName"))
            {

                LoadLastNameData();
            }
            else
            {
                LoadData();
            }
        }





        private void button6_Click(object sender, EventArgs e)
        {
            // Check if any row is selected in the DataGridView
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Access cell values from the selected row
                string id = selectedRow.Cells[0].Value.ToString(); // Replace "ColumnName" with the actual name of the column

                deleteCustomer(Int32.Parse(id));
                LoadData();
            }
            else
            {
                // If no row is selected, print a message indicating that no row is selected
                MessageBox.Show("Please select a customer!!", "Error");
            }


        }

        private void customerPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String[] combobox3toarray = comboBox3.Text.Split();
            int selected_tid = Int32.Parse(combobox3toarray[0]);

            String selected_ct = comboBox2.Text.Equals("1. Store Contact") ? "SC" : "IN";

            int selected_addresstype = -1;


            if (comboBox4.Text.Equals("1 - Home"))
            {
                selected_addresstype = 1;
            }
            else if (comboBox4.Text.Equals("2 - Office"))
            {
                selected_addresstype = 2;
            }
            else
            {
                selected_addresstype = 3;
            }

            string firstname = textBox2.Text;
            string lastname = textBox3.Text;
            string middlename = textBox4.Text;
            string city = textBox5.Text;
            string address = textBox6.Text;
            string address2 = textBox7.Text;
            string postalcode = textBox8.Text;
            string customertype = comboBox2.Text;
            string addresstype = comboBox4.Text;
            string region = comboBox3.Text;
            string storeid = textBox9.Text;
            if (storeid != "" && firstname != null && lastname != null && middlename != null && city != null && address != null && postalcode != null)
            {
                // Define your connection string
                string connectionString = ConnectionData.connectionString;

                // Define the SQL query to call the stored procedure
                string query = "InsertNewCustomer";

                // Create a SqlConnection object
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Create a SqlCommand object for the stored procedure
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Set the command type as stored procedure
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        // Add parameters to the command
                        command.Parameters.AddWithValue("@persontype", selected_ct); // Example value, replace with actual value
                        command.Parameters.AddWithValue("@FirstName", firstname);
                        command.Parameters.AddWithValue("@LastName", lastname);
                        command.Parameters.AddWithValue("@middlename", middlename);
                        command.Parameters.AddWithValue("@territoryid", selected_tid);
                        command.Parameters.AddWithValue("@city", city);
                        command.Parameters.AddWithValue("@postalcode", postalcode);
                        command.Parameters.AddWithValue("@addressline1", address);
                        command.Parameters.AddWithValue("@addressline2", address2);
                        command.Parameters.AddWithValue("@storeid", Int32.Parse(storeid)); // Assuming storeid is an integer
                        command.Parameters.AddWithValue("@addresstypeid", selected_addresstype); // Example value, replace with actual value


                        command.Parameters.Add("@StateProvinceID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        command.Parameters.Add("@NewBusinessEntityID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        command.Parameters.Add("@newaddressid", SqlDbType.Int).Direction = ParameterDirection.Output;

                        try
                        {
                            // Open the connection
                            connection.Open();

                            // Execute the command
                            command.ExecuteNonQuery();

                            // Retrieve the output parameter values
                            int newBusinessEntityID = Convert.ToInt32(command.Parameters["@NewBusinessEntityID"].Value);
                            int newAddressID = Convert.ToInt32(command.Parameters["@newaddressid"].Value);

                            // Use the output parameter values if needed
                            Console.WriteLine("SUCESS");
                        }
                        catch (Exception ex)
                        {
                            // Handle any exceptions
                            Console.WriteLine("Error: " + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Some fields arent valid !", "Error");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void customCustomerGrid(string text)
        {
            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to retrieve data
            string query = "exec storesearch @storename ='" + text + "';";

            // DataTable to store the retrieved data
            DataTable dataTable = new DataTable();

            // Establish connection and execute the query
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Load data into the DataTable
                    dataTable.Load(reader);

                    // Close the reader and the connection
                    reader.Close();
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView2.DataSource = dataTable;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


            dataGridView2.RowHeadersVisible = false;

        }


        private void button8_Click(object sender, EventArgs e)
        {
            Console.WriteLine(textBox1.Text);
            customCustomerGrid(textBox1.Text);
        }





        private void button10_Click(object sender, EventArgs e)
        {
            NewOrder newOrder = new NewOrder();
            newOrder.Visible = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void button11_Click(object sender, EventArgs e)
        {
            // Check if any row is selected in the DataGridView
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];

                // Access cell values from the selected row
                string id = selectedRow.Cells[0].Value.ToString(); // Replace "ColumnName" with the actual name of the column
                textBox9.Text = id;
            }


        }

        private void textBox9_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            // Toggle the visibility of the Add Sales Person panel
            isAddSalesPersonPanelShown = !isAddSalesPersonPanelShown;

            if (isAddSalesPersonPanelShown)
            {
                // Show the panel
                panel4.Show();

                // Set default selections for comboboxes
                comboBox5.SelectedIndex = 0;
                comboBox6.SelectedIndex = 0;
                comboBox7.SelectedIndex = 0;
                comboBox8.SelectedIndex = 0;
                comboBox9.SelectedIndex = 0;
                comboBox12.SelectedIndex = 0;
                comboBox10.SelectedIndex = 0;
                comboBox11.SelectedIndex = 0;

                // If Search Sales Person panel is shown, hide it
                if (isSearchSalesPersonPanelShown)
                {
                    isSearchSalesPersonPanelShown = false;
                    panel5.Hide();
                }
            }
            else
            {
                // Hide the panel
                panel4.Hide();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            // Toggle the visibility of the Search Sales Person panel
            isSearchSalesPersonPanelShown = !isSearchSalesPersonPanelShown;

            if (isSearchSalesPersonPanelShown)
            {
                // Show the panel
                panel5.Show();

                // Set default selection and disable editing for combobox
                comboBox13.SelectedIndex = 1;
                comboBox13.DropDownStyle = ComboBoxStyle.DropDownList;

                // Fill the search results
                fillSearchSalesPersons();

                // If Add Sales Person panel is shown, hide it
                if (isAddSalesPersonPanelShown)
                {
                    isAddSalesPersonPanelShown = false;
                    panel4.Hide();
                }
            }
            else
            {
                // Hide the panel
                panel5.Hide();
            }
        }
 
        private void button14_Click(object sender, EventArgs e)
        {
            string firstName = textBox11.Text;
            string lastName = textBox12.Text;
            string middleName = textBox13.Text;

            string[] combobox5toArray = comboBox5.Text.Split();
            int selected_tid = Int32.Parse(combobox5toArray[0]);

            string city = textBox14.Text;
            string postalCode = textBox15.Text;

            string adr1 = textBox16.Text;
            string adr2 = textBox17.Text;

            string[] combobox6toArray = comboBox6.Text.Split();
            int selected_address_type = Int32.Parse(combobox6toArray[0]);

            string nid = textBox18.Text;
            string loginId = textBox19.Text;
            DateTime birthdate;
            if (!DateTime.TryParseExact(textBox20.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out birthdate))
            {
                MessageBox.Show("Please enter a valid date for the birthday in the format dd/MM/yyyy.");
                return;
            }

            string formattedBirthdate = birthdate.ToString("yyyy-MM-dd");
            Console.WriteLine(formattedBirthdate);
            char maritalStatus = comboBox7.SelectedIndex == 0 ? 'M' : 'S';
            char genderType = comboBox8.SelectedIndex == 0 ? 'M' : 'F';

            bool salariedFlag = comboBox9.SelectedIndex == 0;
            short did = (short)(comboBox10.SelectedIndex == 0 ? 3 : 4);

            int shiftId = comboBox11.SelectedIndex + 1;
            Console.WriteLine(shiftId);
            string email = textBox26.Text;
            string phoneNumber = textBox23.Text;
            int salesquota, bonus, commision;
            if (!int.TryParse(textBox24.Text, out salesquota) ||
                !int.TryParse(textBox21.Text, out bonus) ||
                !int.TryParse(textBox22.Text, out commision))
            {
                MessageBox.Show("Please enter valid numeric values for sales quota, bonus, and commission.");
                return;
            }

            int phoneNumberType = comboBox12.SelectedIndex + 1;

            try
            {
                Console.WriteLine("First Name: " + firstName + ", Type: " + firstName.GetType());
                Console.WriteLine("Last Name: " + lastName + ", Type: " + lastName.GetType());
                Console.WriteLine("Middle Name: " + middleName + ", Type: " + middleName.GetType());
                Console.WriteLine("Selected Territory ID: " + selected_tid + ", Type: " + selected_tid.GetType());
                Console.WriteLine("City: " + city + ", Type: " + city.GetType());
                Console.WriteLine("Postal Code: " + postalCode + ", Type: " + postalCode.GetType());
                Console.WriteLine("Address Line 1: " + adr1 + ", Type: " + adr1.GetType());
                Console.WriteLine("Address Line 2: " + adr2 + ", Type: " + adr2.GetType());
                Console.WriteLine("Selected Address Type ID: " + selected_address_type + ", Type: " + selected_address_type.GetType());
                Console.WriteLine("National ID Number: " + nid + ", Type: " + nid.GetType());
                Console.WriteLine("Login ID: " + loginId + ", Type: " + loginId.GetType());

                Console.WriteLine("Marital Status: " + maritalStatus + ", Type: " + maritalStatus.GetType());
                Console.WriteLine("Gender Type: " + genderType + ", Type: " + genderType.GetType());
                Console.WriteLine("Salaried Flag: " + salariedFlag + ", Type: " + salariedFlag.GetType());
                Console.WriteLine("Department ID: " + did + ", Type: " + did.GetType());
                Console.WriteLine("Shift ID: " + shiftId + ", Type: " + shiftId.GetType());
                Console.WriteLine("Sales Quota: " + salesquota + ", Type: " + salesquota.GetType());
                Console.WriteLine("Bonus: " + bonus + ", Type: " + bonus.GetType());
                Console.WriteLine("Commission: " + commision + ", Type: " + commision.GetType());
                Console.WriteLine("Email: " + email + ", Type: " + email.GetType());
                Console.WriteLine("Phone Number: " + phoneNumber + ", Type: " + phoneNumber.GetType());
                Console.WriteLine("Phone Number Type ID: " + phoneNumberType + ", Type: " + phoneNumberType.GetType());

                using (SqlConnection connection = new SqlConnection(ConnectionData.connectionString))
                {
                    using (SqlCommand command = new SqlCommand("InsertNewSalesPerson", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@middlename", middleName);
                        command.Parameters.AddWithValue("@territoryid", selected_tid);
                        command.Parameters.AddWithValue("@city", city);
                        command.Parameters.AddWithValue("@postalcode", postalCode);
                        command.Parameters.AddWithValue("@addressline1", adr1);
                        command.Parameters.AddWithValue("@addressline2", adr2);
                        command.Parameters.AddWithValue("@addresstypeid", selected_address_type);
                        command.Parameters.AddWithValue("@StateProvinceID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        command.Parameters.AddWithValue("@NewBusinessEntityID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        command.Parameters.AddWithValue("@newaddressid", SqlDbType.Int).Direction = ParameterDirection.Output;
                        command.Parameters.AddWithValue("@nationalidnumber", nid);
                        command.Parameters.AddWithValue("@loginid", loginId);
                        command.Parameters.AddWithValue("@birthdate", formattedBirthdate);
                        command.Parameters.AddWithValue("@MaritalStatus", maritalStatus);
                        command.Parameters.AddWithValue("@Gender", genderType);
                        command.Parameters.Add("@HireDate", SqlDbType.Date).Direction = ParameterDirection.Output;

                        command.Parameters.AddWithValue("@SalariedFlag", salariedFlag);
                        command.Parameters.AddWithValue("@departmentid", did);
                        command.Parameters.AddWithValue("@shiftid", shiftId);
                        command.Parameters.AddWithValue("@SalesQuota", salesquota);
                        command.Parameters.AddWithValue("@Bonus", bonus);
                        command.Parameters.AddWithValue("@CommissionPct", commision);
                        command.Parameters.AddWithValue("@emailaddress", email);
                        command.Parameters.AddWithValue("@phonenumbertypeid", phoneNumberType);

                        command.Parameters.AddWithValue("@phonenumber", phoneNumber);

                        connection.Open();
                        command.ExecuteNonQuery();

                        MessageBox.Show("Stored procedure executed successfully.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

       
        private void button15_Click(object sender, EventArgs e)
        {
            fillSearchSalesPersons();
        }
        private void showActive()
        {
            dataGridView4.DataSource = null;
            string connectionString = ConnectionData.connectionString;
            string procedureName = "acsalesp";

            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(procedureName, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    try
                    {
                        connection.Open();

                        // Clear existing columns and rows in the DataTable
                        dataTable.Columns.Clear();
                        dataTable.Rows.Clear();

                        // Create a DataReader to fetch all columns
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            int numColumns = reader.FieldCount;

                            for (int i = 0; i < numColumns; i++)
                            {
                                // Skip adding column at index 26
                                if (i == 25)
                                {
                                    continue;
                                }

                                string columnName = reader.GetName(i);

                                // Ensure unique column names by appending an index
                                int index = 1;
                                while (dataTable.Columns.Contains(columnName))
                                {
                                    columnName = $"{reader.GetName(i)}_{index}";
                                    index++;
                                }

                                dataTable.Columns.Add(columnName, reader.GetFieldType(i));
                            }

                            while (reader.Read())
                            {
                                DataRow row = dataTable.NewRow();
                                int dataIndex = 0; // Index to track the column index in the DataTable

                                for (int i = 0; i < numColumns; i++)
                                {
                                    // Skip reading column at index 26
                                    if (i == 25)
                                    {
                                        continue;
                                    }

                                    row[dataIndex] = reader[i];
                                    dataIndex++;
                                }

                                dataTable.Rows.Add(row);
                            }
                        }

                        // Clear existing binding and columns in the DataGridView
                        dataGridView4.DataSource = null;
                        dataGridView4.Columns.Clear();

                        // Bind the DataTable to the DataGridView
                        dataGridView4.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void showInactive()
        {
            dataGridView4.DataSource = null;
            string connectionString = ConnectionData.connectionString;
            string procedureName = "insalesp";

            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(procedureName, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    try
                    {
                        connection.Open();

                        // Clear existing columns and rows in the DataTable
                        dataTable.Columns.Clear();
                        dataTable.Rows.Clear();

                        // Create a DataReader to fetch all columns
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            int numColumns = reader.FieldCount;

                            for (int i = 0; i < numColumns; i++)
                            {
                                // Skip adding column at index 26
                                if (i == 25)
                                {
                                    continue;
                                }

                                string columnName = reader.GetName(i);

                                // Ensure unique column names by appending an index
                                int index = 1;
                                while (dataTable.Columns.Contains(columnName))
                                {
                                    columnName = $"{reader.GetName(i)}_{index}";
                                    index++;
                                }

                                dataTable.Columns.Add(columnName, reader.GetFieldType(i));
                            }

                            while (reader.Read())
                            {
                                DataRow row = dataTable.NewRow();
                                int dataIndex = 0; // Index to track the column index in the DataTable

                                for (int i = 0; i < numColumns; i++)
                                {
                                    // Skip reading column at index 26
                                    if (i == 25)
                                    {
                                        continue;
                                    }

                                    row[dataIndex] = reader[i];
                                    dataIndex++;
                                }

                                dataTable.Rows.Add(row);
                            }
                        }

                        // Clear existing binding and columns in the DataGridView
                        dataGridView4.DataSource = null;
                        dataGridView4.Columns.Clear();

                        // Bind the DataTable to the DataGridView
                        dataGridView4.DataSource = dataTable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }


        private void fillSearchSalesPersons()
        {
            string connectionString = ConnectionData.connectionString;
            string procedureName = "vsalesperson";

            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(procedureName, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    try
                    {
                        connection.Open();
                        adapter.Fill(dataTable);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView4.DataSource = dataTable;


            dataGridView4.RowHeadersVisible = false;
            dataGridView4.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void searchSPID()
        {
            String text = textBox25.Text;
            if (IsArithmetic(text))
            {

                // Connection string to your SQL Server
                string connectionString = ConnectionData.connectionString;

                // SQL query to retrieve data
                string query = "exec spsearch @businessentityid   =" + text + ";";
                Console.WriteLine(query);
                // DataTable to store the retrieved data
                DataTable dataTable = new DataTable();

                // Establish connection and execute the query
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        // Load data into the DataTable
                        dataTable.Load(reader);

                        // Close the reader and the connection
                        reader.Close();
                    }
                }

                // Bind the DataTable to the DataGridView
                dataGridView4.DataSource = dataTable;


            }
            else
            {
                MessageBox.Show("Not Aritmetic Value", "Error");
            }
        }



        private void searchLN()
        {
            String text = textBox25.Text;


            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to retrieve data
            string query = "exec spsearch @lastname    =" + text + ";";
            Console.WriteLine(query);
            // DataTable to store the retrieved data
            DataTable dataTable = new DataTable();

            // Establish connection and execute the query
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Load data into the DataTable
                    dataTable.Load(reader);

                    // Close the reader and the connection
                    reader.Close();
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView4.DataSource = dataTable;


        }



        private void emailSearch()
        {
            string text = textBox25.Text;

            // Ensure text is not empty or null
            if (!string.IsNullOrWhiteSpace(text))
            {
                // Connection string to your SQL Server
                string connectionString = ConnectionData.connectionString;

                // SQL query to retrieve data
                string query = "EXEC spsearch @emailaddress = " + text + " ";

                // DataTable to store the retrieved data
                DataTable dataTable = new DataTable();

                // Establish connection and execute the query
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Add parameter
                            command.Parameters.AddWithValue("@text", text);

                            connection.Open();
                            SqlDataReader reader = command.ExecuteReader();

                            // Load data into the DataTable
                            dataTable.Load(reader);

                            // Close the reader and the connection
                            reader.Close();
                        }
                    }

                    // Bind the DataTable to the DataGridView
                    dataGridView4.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error executing query: " + ex.Message);
                }
            }
            else
            {
                Console.WriteLine("Textbox text is empty or null.");
            }
        }


        private void searchAddress()
        {
            String text = textBox25.Text;


            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to retrieve data
            string query = "exec spsearch @addressline1    =" + text + ";";
            Console.WriteLine(query);
            // DataTable to store the retrieved data
            DataTable dataTable = new DataTable();

            // Establish connection and execute the query
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Load data into the DataTable
                    dataTable.Load(reader);

                    // Close the reader and the connection
                    reader.Close();
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView4.DataSource = dataTable;


        }

        private void StoreNameSearch()
        {
            String text = textBox25.Text;
            {

                // Connection string to your SQL Server
                string connectionString = ConnectionData.connectionString;

                // SQL query to retrieve data
                string query = "exec spsearch @storename   =" + text + ";";
                Console.WriteLine(query);
                // DataTable to store the retrieved data
                DataTable dataTable = new DataTable();

                // Establish connection and execute the query
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        // Load data into the DataTable
                        dataTable.Load(reader);

                        // Close the reader and the connection
                        reader.Close();
                    }
                }

                // Bind the DataTable to the DataGridView
                dataGridView4.DataSource = dataTable;


            }
        }





        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void button16_Click(object sender, EventArgs e)
        {
            showActive();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            showInactive();
        }

        private void comboBox13_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox25_TextChanged(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (comboBox13.SelectedIndex == 0)
            {

                searchSPID();

            }
            else if (comboBox13.SelectedIndex == 1)
            {
                searchAddress();
            }
            else if (comboBox13.SelectedIndex == 2)
            {
                searchLN();
            }
            else if (comboBox13.SelectedIndex == 3)
            {
                emailSearch();
            }
            else
            {
               StoreNameSearch();
            }
            }

        private void deactivateSP(string id)
        {
            // Get the parameter value from the TextBox
 

            // Connection string to your SQL Server
            string connectionString = ConnectionData.connectionString;

            // SQL query to call the stored procedure
            string query = "exec deactsp @businessentityid";

            try
            {
                // Establish connection and execute the query
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameter to the command
                        command.Parameters.AddWithValue("@businessentityid", id);

                        // Open the connection
                        connection.Open();

                        // Execute the query
                        command.ExecuteNonQuery();

                        // Close the connection
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle any errors that occur during the execution
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void button19_Click(object sender, EventArgs e)
        {
            // Check if any row is selected in the DataGridView
            if (dataGridView4.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView4.SelectedRows[0];

                // Access cell values from the selected row
                string id = selectedRow.Cells[0].Value.ToString(); // Replace "ColumnName" with the actual name of the column

                deactivateSP(id);
                 
                fillSearchSalesPersons();
            }
            else
            {
                // If no row is selected, print a message indicating that no row is selected
                MessageBox.Show("Please select a customer!!", "Error");
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void datagrid3(string customerId)
        {
            // Assuming you have a connection to your database and a SQL query to fetch data for dataGridView3
            string connectionString = ConnectionData.connectionString;
            string query = "EXECUTE customersales @customerid = " + customerId +   ";" ;
            Console.WriteLine(query);
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerId", customerId);

                    connection.Open();

                    // Assuming you have a DataTable to hold the result
                    DataTable dataTable = new DataTable();

                    // Load data from SQL query into DataTable
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);

                    // Bind DataTable to dataGridView3
                    dataGridView3.DataSource = dataTable;
                }
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {    // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Access cell values from the selected row
                string id = selectedRow.Cells[1].Value.ToString(); // Replace "ColumnName" with the actual name of the column
                datagrid3(id);
            }
            else
            {
                MessageBox.Show("Please select one row", "Error");
            }
        }
    }
}

 